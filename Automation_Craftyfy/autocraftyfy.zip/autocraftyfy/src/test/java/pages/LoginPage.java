package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    WebDriver driver;

    By loginLink = By.linkText("Login");
    By email = By.name("email");
    By password = By.name("password");
    By loginBtn = By.xpath("//button[contains(text(),'Login')]");

    public LoginPage(WebDriver driver) {
        this.driver = driver;
    }

    public void login(String userEmail, String userPass) {
        driver.findElement(loginLink).click();
        driver.findElement(email).sendKeys(userEmail);
        driver.findElement(password).sendKeys(userPass);
        driver.findElement(loginBtn).click();
    }
}
