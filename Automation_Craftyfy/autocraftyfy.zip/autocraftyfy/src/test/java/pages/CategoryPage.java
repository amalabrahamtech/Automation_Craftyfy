package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CategoryPage {
    WebDriver driver;

    public CategoryPage(WebDriver driver) {
        this.driver = driver;
    }

    public void viewCategory(String categoryName) {
        driver.findElement(By.linkText("Categories")).click();
        driver.findElement(By.xpath("//button[contains(text(),'" + categoryName + "')]")).click();
    }

    public void resetFilter() {
        driver.findElement(By.id("resetFilter")).click();
    }
}
