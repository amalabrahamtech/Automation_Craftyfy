package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage {
    WebDriver driver;

    By registerLink = By.linkText("Register");
    By email = By.name("email");
    By password = By.name("password");
    By registerBtn = By.xpath("//button[contains(text(),'Register')]");

    public RegisterPage(WebDriver driver) {
        this.driver = driver;
    }

    public void register(String emailInput, String passwordInput) {
        driver.findElement(registerLink).click();
        driver.findElement(email).sendKeys(emailInput);
        driver.findElement(password).sendKeys(passwordInput);
        driver.findElement(registerBtn).click();
    }
}
