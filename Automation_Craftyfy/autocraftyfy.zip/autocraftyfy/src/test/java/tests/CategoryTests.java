package tests;

import base.BaseTest;
import org.testng.annotations.Test;
import pages.CategoryPage;

public class CategoryTests extends BaseTest {

    @Test
    public void TC_U2_01_viewCategories() {
        CategoryPage category = new CategoryPage(driver);
        category.viewCategory("Art");
    }

    @Test
    public void TC_U2_04_resetCategory() {
        CategoryPage category = new CategoryPage(driver);
        category.resetFilter();
    }
}

