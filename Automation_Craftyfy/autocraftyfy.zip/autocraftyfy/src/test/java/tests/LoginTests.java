package tests;

import base.BaseTest;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginTests extends BaseTest {

    @Test
    public void TC_U1_03_validLogin() {
        LoginPage login = new LoginPage(driver);
        login.login("Testuser13@gmail.com", "testuser13");
    }

    @Test
    public void TC_U1_04_invalidLogin() {
        LoginPage login = new LoginPage(driver);
        login.login("wrong@email.com", "wrongpass");
    }
}
