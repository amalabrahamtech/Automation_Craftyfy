package tests;

import base.BaseTest;
import org.testng.annotations.Test;
import pages.RegisterPage;

public class RegisterTests extends BaseTest {

    @Test
    public void TC_U1_01_validRegistration() {
        RegisterPage register = new RegisterPage(driver);
        String email = "test" + System.currentTimeMillis() + "@mail.com";
        register.register(email, "Valid1234");
    }

    @Test
    public void TC_U1_02_existingEmail() {
        RegisterPage register = new RegisterPage(driver);
        register.register("Testuser13@gmail.com", "testuser13");
    }
}
